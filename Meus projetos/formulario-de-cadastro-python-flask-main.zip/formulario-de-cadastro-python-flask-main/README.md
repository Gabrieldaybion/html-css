# formulario-de-cadastro-python-flask
 formulario de cadastro para login usando python e flask
 como criar um formulario e atraves dele cadastrar membros em um banco de dados local usando json
